The requirements are designed for a product which will be used as a VR program for upcoming doctors and surgeons.
There is one scene, the Operation theater and its a multi player VR, such that more than one can use this simultaneously.
In the operation theater there are articles, like scalpel, scissors, seperators  etc. which will be used to perform an operation on a virtual human body.
The interactions between the articles and the human body are captured. they cannot interact among them other than human body.
