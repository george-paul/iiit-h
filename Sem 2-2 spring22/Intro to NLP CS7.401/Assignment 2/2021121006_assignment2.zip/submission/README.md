# README

## Intro to NLP - Assignment 2

To run the model execute:
```
python3 src.py
```
