# Intro to NLP - Assignment 1

### Tokenizer

Usage:

```
python tokenize.py <path to input file>
```

### Language Model

Only trains a model that holds a dictionary of counts

Usage:

```
python language_model.py <n_value, default=4> <smoothing type, default=K> <path to corpus, default="./corpus.txt">
```

