# DASS - Assignment 3.1 README

The game consists of a king and some empty tiles.

The king is depicted with a `K`.

## Controls

* Move the king using the `WASD` keys.
* End the game by pressing the `Esc` key.