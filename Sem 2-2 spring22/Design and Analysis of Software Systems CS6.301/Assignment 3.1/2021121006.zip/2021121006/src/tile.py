class Tile:
	def __init__(self):
		self.r = 0
		self.c = 0
	def __init__(self, r, c):
		self.r = r
		self.c = c