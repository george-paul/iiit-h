---
author: George Paul (2021121006)
---



# Design and Analysis of Software Systems - Assignment 1

## IIITH Food Portal

Uses the MERN stack to implement an app for food ordering around the IIITH campus

* Login and Register new user implemented.