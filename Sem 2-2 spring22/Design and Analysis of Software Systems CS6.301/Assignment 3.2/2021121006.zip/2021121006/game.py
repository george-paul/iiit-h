print("Press any key to start game")
from src import run

run.runGame()