class Tile:
	def __init__(self):
		self.r = 0
		self.c = 0
		self.disp = "_"
	def __init__(self, r, c):
		self.r = r
		self.c = c
		self.disp = "_"
	def __init__(self, r, c, disp):
		self.r = r
		self.c = c
		self.disp = disp