#ifndef BUILTINS
#define BUILTINS

void changeDir(char **, char*);
void printWD();
void echoecho(char**);
void listDriver(char**);
int getArgc(char**);

#endif