#ifndef PROCESSES
#define PROCESSES

void launchProcess(char **);
void processInfo(char**);

#endif